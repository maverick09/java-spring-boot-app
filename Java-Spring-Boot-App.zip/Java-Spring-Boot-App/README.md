Passwords Project
=================

This project contains the Java microservice project for all password journeys.
It exposes services to manage password creation and recovery as well as tokenResponse validation.


