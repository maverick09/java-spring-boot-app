package com.interview.api.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PasswordsServiceImpl implements PasswordsService {

    @Autowired
    public PasswordsServiceImpl() {
    }

    /**
     * @inheritDoc
     */
    @Override
    public boolean isValidEmail(String emailAddress) {
        //Implement
        return true;
    }
}
