package com.interview.api.service;

public interface PasswordsService {

    /**
     * Tells if the email-id is valid
     *
     * @param address is a text that contains the email address that needs to be validated
     *
     * @return a simple boolean is the email is a valid email
     */
    boolean isValidEmail(String address);
}
