package com.interview.api.rest;

import com.interview.api.service.PasswordsService;
import com.talktalk.api.util.content.ObjectMappers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MockServletContext.class)
public class PasswordsControllerTest {


    private static final String EMAIL_ADDRESS_THAT_BELONGS_TO_AN_EXISTING_CUSTOMER = "someone@somehwere.com";

    private static final String ENDPOINT_URL_VALIDATE_EMAIL_ADDRESS = "/passwords/email/{emailAddress}";

    private MockMvc mockMvc;

    @MockBean
    private PasswordsService passwordsService;

    @Before
    public void setUp() {
        PasswordsController passwordsController = new PasswordsController(passwordsService);
        mockMvc = MockMvcBuilders.standaloneSetup(passwordsController).setControllerAdvice()
                                 .setMessageConverters(new MappingJackson2HttpMessageConverter(
                                     ObjectMappers.newParameterNamesAwareObjectMapper())).build();
    }

    @Test
    public void shouldValidateEmailAddressHappyPath() throws Exception {
        mockMvc.perform(get(ENDPOINT_URL_VALIDATE_EMAIL_ADDRESS, EMAIL_ADDRESS_THAT_BELONGS_TO_AN_EXISTING_CUSTOMER)
                .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());
    }
}
