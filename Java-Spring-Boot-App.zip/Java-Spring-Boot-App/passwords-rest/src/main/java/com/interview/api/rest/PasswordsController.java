package com.interview.api.rest;

import com.talktalk.api.online.passwords.client.response.*;
import com.interview.api.service.PasswordsService;
import com.talktalk.api.util.error.exception.ApiError;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(value = "", produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
@Api(value = "/passwords")
public class PasswordsController {

    private PasswordsService passwordsService;

    @Autowired
    public PasswordsController(PasswordsService passwordsService) {
        this.passwordsService = passwordsService;
    }

    @ApiOperation(value = "Check whether an email belongs to an existing customer", notes = "Check whether an email belongs to an existing customer")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "When the email address belongs to an existing customer."),
        @ApiResponse(code = 404, message = "When the email address does not belong to any existing customer.", response = ApiError.class),})
    @GetMapping("/passwords/email/{emailAddress:.+}")
    public ResponseEntity<EmailValidationResponse> validateEmailAddress(@PathVariable("emailAddress") String emailAddress) {

        EmailValidationResponse emailValidationResponse =
            new EmailValidationResponse(passwordsService.isValidEmail(emailAddress));
        return new ResponseEntity<>(emailValidationResponse, HttpStatus.OK);
    }
}