package com.interview.api.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.time.LocalDate;

import static java.util.Arrays.asList;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@SpringBootApplication(scanBasePackages = {"com.talktalk.api.online.passwords.rest", "com.talktalk.api.util",
                                           "com.talktalk.api.util.error"})
@EnableSwagger2
public class ApplicationMain {

    public static void main(String[] args) {
        SpringApplication.run(ApplicationMain.class, args);
    }

    @Bean
    public Docket passwordsApi() {
        return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.any())
                                                      .paths(PathSelectors.any()).build().pathMapping("/")
                                                      .directModelSubstitute(LocalDate.class, String.class)
                                                      .genericModelSubstitutes(ResponseEntity.class)
                                                      .useDefaultResponseMessages(false)
                                                      .globalResponseMessage(RequestMethod.GET,
                                                                             asList(serverError(), badRequest()))
                                                      .globalResponseMessage(RequestMethod.POST,
                                                                             asList(serverError(), badRequest()))
                                                      .globalResponseMessage(RequestMethod.PUT,
                                                                             asList(serverError(), badRequest()));
    }

    private ResponseMessage badRequest() {
        return new ResponseMessageBuilder().code(BAD_REQUEST.value()).message("Bad request, check input parameters.")
                                           .responseModel(new ModelRef("ApiError")).build();
    }

    private ResponseMessage serverError() {
        return new ResponseMessageBuilder().code(INTERNAL_SERVER_ERROR.value()).message("Server error")
                                           .responseModel(new ModelRef("ApiError")).build();
    }

    @Bean
    public RequestMappingHandlerMapping getRequestMappingHandlerMapping() {
        RequestMappingHandlerMapping requestMappingHandlerMapping = new RequestMappingHandlerMapping();
        requestMappingHandlerMapping.setUseRegisteredSuffixPatternMatch(false);
        requestMappingHandlerMapping.setUseSuffixPatternMatch(false);
        return requestMappingHandlerMapping;
    }
}
